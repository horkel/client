# History Settings
HISTCONTROL=ignoreboth
export HISTTIMEFORMAT='%F %T '
shopt -s histappend
HISTSIZE=1024
HISTFILESIZE=2048
HISTIGNORE="ls:la:ll:clear:pwd:history:tree"
HISTFILE="$HOME/.cache/bash_history"
