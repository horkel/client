# Locale Settings
export TIME_STYLE='+%Y/%m/%d %H:%M:%S'
export TZ='Asia/Chongqing'
LANG="en_US.UTF-8"
